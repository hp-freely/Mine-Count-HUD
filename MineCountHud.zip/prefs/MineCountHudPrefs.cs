////
// Mine Count Hud is configured in two locations:
//   1) The in-game Options tab allows you to configure items that you might want to change on the fly: Whether or not to displaly
//      the HUD, and the HUD transparency
//   2) This prefs file allows you to configure less commonly changed items: Mine Count Text and HUD Styling
////

	// the prefix text displayed before mine count value in the HUD
	// example: "M:3"
MineCountHud.mineCountTextPrefix = "M:";

	// width, height, and font preferences of the mine count text
MineCountHud.Mine_Count_HUD_Height = 20;
MineCountHud.Mine_Count_HUD_Width = 26;
MineCountHud.Mine_Count_Text_Font_Name = "Supertouch";
MineCountHud.Mine_Count_Text_Font_Size = "14";
MineCountHud.Mine_Count_Text_Font_Color = "A9D7FA";