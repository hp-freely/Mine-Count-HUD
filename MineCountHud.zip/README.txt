////
// The purpose of Mine Count HUD is to create a small HUD for tracking the number of mines you currently have in your inventory. This is something that
// you should put somewhere around your reticle for quick reference.
//
// Historically, servers have provided players with 3 mines. Usually 3 mines is absolutely plenty. If you actually live long enough
// to use your 3 mines, you will most definitely pick up more from dead bodies.
//
// However, servers have now started moving 1 mine for LT. 1 mine is much more difficult to track for the following reasons:
// a) In the action of the game, you may forget whether or not you've already used your 1 mine or not.
// b) When you walk over a dead body, it's not guaranteed that you'll pick up a mine. If you do, then you definitely want to know.
//
// The T2 ammo bar takes up a lot of real estate on the screen, so people generally keep it at the bottom or top of the screen. With larger
// resolutions, you actually have to take your eyes off the game to see your mine count.
//
// Having a smaller HUD next to your reticle means you can see your mine count immediately and act appropriately in that moment.
////

--Known Bugs--
This script uses the support script support/loadout.cs. This script is supposed to correctly track your current minecount using loadout.getMineAmmo(). There is a bug with this
method call where the loadout value doesn't get correctly set in the following scenario:
a) You have a given number of mines in your inventory (including 0 mines).
b) You leave the game.
c) You rejoin a game.
d) When you respawn the number of mines assigned at spawn does *not* equal the total number of mines in your inventory when you previously left a game.

Explicitly, when you rejoin and respawn, the loadout.getMineAmmo() will equal the mine count which was applicable when previously left the match.

I could work around this by tracking the mine count in Mine Count Hud script itself, but it's just not worth the effort. It's a temporary state that only applies the first time you spawn.


Dependencies
You must ensure you support the following dependencies:
1. HudManager.vl2
2. UberGuy's Script Suite. 
   (I am unsure what supports this. This must include: a) Scripts tab in the browser, b) UberPrefs support. Both of the these are included in the all-in-one download.)
	
Instructions
1. Move MineCountHud.vl2 to your z_scripts or scripts folder
2. Move prefs/MineCountHudPrefs.cs to your base/prefs folder
3. Use the browser Script tab to configure transparency or HUD visibility, if desired.
4. Use the prefs file to configure HUD style and the HUD prefix text, if desired.
5. After loading a map, use HudMover to position the HUD as needed: 
    - "Free Mine Count HUD" 